import os


def get_three_last_lines(archieve_name:str) -> list:

    with open(f'steps/{archieve_name}', 'r') as file:

        lines = file.readlines()
    
    last_three_lines = lines[:]
    three_lines = []

    for line in last_three_lines:

        line = line.strip()
        list = line.split('/')[0]
        list = list.replace('[', '')
        list = list.replace(']', '')


        list = list.split(',')


        for i in range(len(list)):

            
            list[i] = list[i].strip()

            if list[i] == 'False':
                

                list[i] = False

            elif list[i] == 'True':

                list[i] = True
            
            else:

                list[i] = 'algo'
        
        three_lines.append(list)


    return three_lines


groundTruth = get_three_last_lines('steps0.txt')     #nome_txt_professor
studentResult = get_three_last_lines('steps1.txt')   #nome_txt_aluno

sizeGroundTruth = len(groundTruth)
sizeStudentResult = len(studentResult)

''' 

    O primeiro passo é verificar se o tamanho do groundTruth é igual ao tamanho do studentResult.

'''

if sizeGroundTruth > sizeStudentResult:

    print('Há passos faltando no experimento :c ')

elif sizeStudentResult < sizeGroundTruth:
    
    print('Há passos a mais no experimento :c ')

else:

    print('O número de passos é igual :) ')

    sameSize = True

'''

    O segundo passo é verificar se os passos do groundTruth são iguais aos passos do studentResult.

'''

vetorCorrecao = []
with open('comparacao.txt', 'w') as file:

    if sameSize == True:

        print(sizeGroundTruth)

        for i in range(sizeGroundTruth):

            passo_verdade = groundTruth[i]
            #print(len(passo_verdade) )

            passo_estudante = studentResult[i]

            if passo_verdade != passo_estudante:
                
                # print(groundTruth[i])
                # print(studentResult[i])

                # print(f'O passo {i} não é igual :c ')

                # print('Passo GroundTruth: ', groundTruth[i])
                # print('Passo StudentResult: ', studentResult[i])

                
                for contador in range(len(passo_verdade)):

                    #print(contador)

                    #print(passo_verdade[contador], ' e ', passo_estudante[contador])

                    if passo_verdade[contador] == passo_estudante[contador]:

                        #print('comparando o certo {} com {}'.format(groundTruthList[0], studentResultList[0]))

                        vetorCorrecao.append(1)
                    
                    else:
                
                        #print('comparando errado {} com {}'.format(groundTruthList[0], studentResultList[0]))

                        vetorCorrecao.append(0)


            else:

                for k in range(len(passo_verdade)):

                    vetorCorrecao.append(1)


            

            # file.write(f"Passo do professor: , {groundTruth[i]} \n")
            # file.write(f"Passo do aluno: , {studentResult[i]} \n")
            # file.write(f"O passo {i} nao e igual :c \n")

            file.write(f"Vetor do passo {i} -> {vetorCorrecao}\n")

            file.flush()
            
            print(vetorCorrecao)
            vetorCorrecao = []