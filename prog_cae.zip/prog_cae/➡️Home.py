import streamlit as st
import pandas as pd
import mysql.connector
from streamlit_autorefresh import st_autorefresh
from PIL import Image

planta_ligada = False

html_template1 = f'''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        .container {{
            display: flex;
            align-items: center;
        }}
        .bolinha {{
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: {'green' if planta_ligada else 'red'};
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5); /* Sombra */
            border: 2px solid #ccc; /* Borda cinza */
            margin-right: 10px;
        }}
        .comentario {{
            font-size: 16px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div id="bolinha" class="bolinha"></div>
        <div class="comentario" id="comentario">{'Planta ligada' if planta_ligada else 'Planta desligada'}</div>
    </div>

</body>
</html>
'''

print(html_template1)


####################### CRUD

def inserir_dados_msg(msg, code_msg):
    mydb2 = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb2.cursor()
    sql3 = "INSERT INTO mensagem (msg, code_msg) VALUES (%s, %s)"
    val1 = (msg, code_msg)
    mycursor.execute(sql3, val1)
    mydb2.commit()  # Você esqueceu de commitar a transação
    mydb2.close()

def inserir_dados_planta(Planta_id, plant_name,endpoint, io_opcua_id, planta_status ):
    mydb3 = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb3.cursor()
    sql4 = "INSERT INTO planta (Planta_id, plant_name,endpoint, io_opcua_id, planta_status) VALUES (%s, %s,%s, %s, %s)"
    val2 = (Planta_id, plant_name,endpoint, io_opcua_id, planta_status)
    mycursor.execute(sql4, val2)
    mydb3.commit()  # Você esqueceu de commitar a transação
    mydb3.close()

def deletar_dados_msg(code_msg):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb.cursor()
    sql = "DELETE FROM mensagem WHERE code_msg = %s"
    val = (code_msg,)
    mycursor.execute(sql, val)
    mydb.commit()
    mydb.close() 

def atualizar_dados_msg(code_msg, nova_msg):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb.cursor()
    sql = "UPDATE mensagem SET msg = %s WHERE code_msg = %s"
    val = (nova_msg, code_msg)
    mycursor.execute(sql, val)
    mydb.commit()
    mydb.close()

########################### 

def executar_consulta(sql):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    data = mycursor.fetchall()
    columns = [desc[0] for desc in mycursor.description]
    df = pd.DataFrame(data, columns=columns)
    mydb.close()
    return df


def mostrar_tabela():
   
    sql = "SELECT produção_id, tipo_produto, qtd_ordem, Producao_inicio, Producao_fim, IO_OPCUA_id  FROM producao"
    df = executar_consulta(sql)
    df.set_index(df.columns[0], inplace=True)
    st.write(df)
    
def mostrar_mensagens():
    
    sql3 = "SELECT * FROM mensagem"
    mp = executar_consulta(sql3)
    mp.set_index(mp.columns[0], inplace=True)
    st.write(mp)
    
def atualiza_tabela():
    
    st.subheader("Atualizar Dados")
    code_msg_update = st.text_input("Código da Mensagem para Atualizar:")
    nova_msg = st.text_input("Nova Mensagem:")
    if st.button("Atualizar"):
        atualizar_dados_msg(code_msg_update, nova_msg)
        st.success("Dados atualizados com sucesso!")
        
    
    
    
#def mostra_tabela_io_opcua():
#   
#    sql4 = "SELECT * FROM io_opcua"
#    mp2 = executar_consulta(sql4)
#    def bolinha(status_item):
#        cor = 'green' if status_item == 'Ativo' else 'red'
#        return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'
#    mp2['ON/OFF'] = mp2['status_item'].apply(bolinha)
#    mp2.set_index(mp2.columns[0], inplace=True)
#    
#    st.write(mp2)    

def mostra_tabela_io_opcua():
    #sql4 = "SELECT * FROM io_opcua"
    query_plantas = "SELECT plant_name FROM `planta`"
    result_plantas = executar_consulta(query_plantas)
    option = st.selectbox('selecione a planta desejada',result_plantas, index=None)

    st.write('You selected:', option)
    if(option is None):
        st.header("Nenhuma planta foi selecionada")
    else:    
        sql4 = f"SELECT `item_opcua`, `action_r_w`, `status_item`, `tipo` FROM `io_opcua` WHERE plant_name = '{option}'"
        mp2 = executar_consulta(sql4)
        if (len(mp2) == 0):
            st.header("Nenhuma entrada ou saída foi cadastrada nesta planta")
        else:

            def bolinha(status_item):
                cor = 'green' if status_item == 'Ativo' else 'red'
                return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'

            # Adicionando uma coluna de bolinhas ao DataFrame
            mp2['Bolinha'] = mp2['status_item'].apply(bolinha)

            # Exibindo a tabela com as bolinhas usando st.write
            st.write(mp2.to_html(escape=False), unsafe_allow_html=True)



#def gera_grafico():
#    sql = "SELECT id,  quantidade FROM produtos"
#    df = executar_consulta(sql)
#    st.bar_chart(df.set_index('id'))
#     

def criar_nova_tabela():
    sql5 = "SELECT * FROM producao"
    opcao1 = executar_consulta(sql5)
    opcao1['total'] = opcao1['qtd_produto'] * opcao1['qtd_ordem']
    colunas_selecionadas = ['produção_id', 'tipo_produto', 'total']  # Substitua com os nomes das colunas desejadas
    opcao1 = opcao1[colunas_selecionadas]
    opcao1.set_index(opcao1.columns[0], inplace=True)
    st.write(opcao1)
    st.bar_chart(opcao1.set_index('tipo_produto'))

def mostra_planta():
    sql6 = "SELECT * FROM planta"
    mp3 = executar_consulta(sql6)
    mp3.set_index(mp3.columns[0], inplace=True)
    st.write(mp3)

 
def cadastrar_msg():
    
        st.subheader("Adicionar Dados de mensagem")

        # Campos para inserir nome e idade
        msg = st.text_input("Mensagem")
        code_msg = st.number_input("Código da mensagem", min_value=0, max_value=150, step=1)

        # Botão para inserir os dados
        if st.button("Inserir Dados", key="inserir_msg"):
            if msg and code_msg:
                inserir_dados_msg(msg, code_msg)
                st.success("Dados inseridos com sucesso!")
            else:
                st.error("Por favor, preencha todos os campos.")

def deletar_dados():
    st.subheader("Deletar Dados")
    code_msg_delete = st.text_input("Código da Mensagem para Deletar:")
    if st.button("Deletar"):
        deletar_dados_msg(code_msg_delete)
        st.success("Dados deletados com sucesso!")
    

def cadastrar_planta():
    
        st.title("Adicionar Planta")

        # Campos para inserir nome e idade
        Planta_id = st.text_input("ID planta")
        plant_name = st.text_input("Nome da planta")
        endpoint = st.text_input("Endpoint")
        #io_opcua_id  = st.number_input("IO OPCUA ID", min_value=0, max_value=150, step=1)
        planta_status = st.text_input("Status (Ativo/ Inativo)")

        # Botão para inserir os dados
        if st.button("Inserir Dados", key="inserir_planta"):
            if Planta_id and plant_name and endpoint and io_opcua_id and planta_status:
                inserir_dados_planta(Planta_id, plant_name,endpoint, io_opcua_id, planta_status)
                st.success("Dados inseridos com sucesso!")
            else:
                st.error("Por favor, preencha todos os campos.")                  

def listar_plantas():
    
    
    mydb7 = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    
    # Cursor para executar consultas SQL
    mycursor7 = mydb7.cursor()

    # Consulta para selecionar as plantas cadastradas
    sql7 = "SELECT plant_name FROM planta"

    # Executando a consulta
    mycursor7.execute(sql7)

    # Obtendo os resultados da consulta
    plantas = [plant[0] for plant in mycursor7.fetchall()]

    # Fechando a conexão com o banco de dados
    mydb7.close()
    
    # Criando o seletor de plantas no sidebar
    planta_selecionada = st.sidebar.selectbox("Selecione a planta", plantas)
    
    if planta_selecionada == "Magfront":
        mostra_tabelaCPLAB()
        
    if planta_selecionada == "MagBack":
        mostra_tabelaA()
    
    if planta_selecionada == "Measuring":
        mostra_tabelaB()
        
    if planta_selecionada == "Drill":
        mostra_tabelaC()
    
    if planta_selecionada == "Planta D":
        mostra_tabelaD()
    
    if planta_selecionada == "Planta E":
        mostra_tabelaE()
        
    if planta_selecionada == "Planta ABC":
        mostra_tabelaABC()

    return planta_selecionada

def pagina_inicial():

    st.image('https://super.ufam.edu.br/wp-content/uploads/2020/05/MARCA_Prancheta-1-c%C3%B3pia-1.png', width=400, use_column_width=False)

    #use_column_width=False
    
    #st.title("Produção CP Lab")
    ##  para mais um topico separado na aba     st.sidebar.title('Cabeçalho Personalizado')
    ##st.write(html_template1, unsafe_allow_html=True)
    st.image("https://www.festo.com/media/pim/341/D15000100172341_1056x1024.jpg", caption="CP Lab 400",width=450)
    
    mostrar_tabela()
    #gera_grafico()
    
    

def segunda_pagina():
    # st.write("Esta é a segunda página.")
    # st.title("Produção total")
    # criar_nova_tabela()
    st.title("Tabela de IOs")
    mostra_tabela_io_opcua()
    
    
    
def terceira_pagina():
    
    st.title("Mensagens da produção")
    mostrar_mensagens()

        
def mostra_tabelaCPLAB():
    
    sql8 = "SELECT plant_name , endpoint, io_opcua_id FROM planta WHERE plant_name = 'cplab' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
    
def mostra_tabelaA():
    
    sql8 = "SELECT plant_name , endpoint, io_opcua_id FROM planta WHERE plant_name = 'Planta A' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)

def mostra_tabelaB():
    
    sql8 = "SELECT plant_name , endpoint, io_opcua_id FROM planta WHERE plant_name = 'Planta B' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)

def mostra_tabelaC():
    
    sql8 = "SELECT plant_name , endpoint, io_opcua_id FROM planta WHERE plant_name = 'Planta C' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
    
def mostra_tabelaD():
    
    sql8 = "SELECT plant_name , endpoint, io_opcua_id FROM planta WHERE plant_name = 'Planta D' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
    
def mostra_tabelaE():
    
    sql8 = "SELECT plant_name , endpoint, io_opcua_id FROM planta WHERE plant_name = 'Planta E' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
    
def mostra_tabelaABC():
    
    sql8 = "SELECT plant_name , endpoint, io_opcua_id FROM planta WHERE plant_name = 'Planta ABC' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
 
 
def atualiza_pagina():
    
    count = st_autorefresh(interval=100, limit=100, key="fizzbuzzcounter")

    # The function returns a counter for number of refreshes. This allows the
    # ability to make special requests at different intervals based on the count
    if count == 0:
        st.write("Count is zero")
    elif count % 3 == 0 and count % 5 == 0:
        st.write("FizzBuzz")
    elif count % 3 == 0:
        st.write("Fizz")
    elif count % 5 == 0:
        st.write("Buzz")
    else:
        st.write(f"Count: {count}")
       
def teste_mostrar():
    st.write("teste")
    
def main():
    #pagina_inicial()
    #st.sidebar.title("Menu")
    # menu = ["Produção CP Lab", "Monitoramento", "Informações da Planta"]
    # escolha = st.sidebar.selectbox("Navegue", menu)

    # if escolha == "Produção CP Lab":
    #     pagina_inicial()
    # elif escolha == "Monitoramento":
    #     segunda_pagina()
    # elif escolha == "Informações da Planta":
    #     terceira_pagina()
    # # elif escolha in plantas:
    # #     mostra_planta()
    # logo = Image.open('images/ufam.png')
    # logo = logo.resize((200, 200))

    # st.image(logo)
    st.markdown("<h1 style='text-align: center; color: blue;'>ACE - Automatic Correction of Experiments</h1>", unsafe_allow_html=True)
    #st.title("ACE - Automatic Correction of Experiments")
    col1, col2,col3 = st.columns(3)


    with col1:
        st.header("CP_LAB")
        st.image("https://www.festo.com/media/pim/341/D15000100172341_1056x1024.jpg",width=220)
        botao = st.button("To Enter")
        #botao.on_click(teste_mostrar)
    

    with col2:
        st.header("MEASURING")
        planta = Image.open('images/planta.png')
        planta = planta.resize((1024, 1024))
        st.image(planta)
        botao_col2 = st.button("To Enter",key=teste_mostrar)

    # with col3:
    #     st.header("An owl")
    #     st.image("https://static.streamlit.io/examples/owl.jpg")

    

if __name__ == "__main__":
    main()
    #atualiza_pagina()




