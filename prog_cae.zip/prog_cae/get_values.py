from opcua import Client
from opcua import ua



Endpoint = 'opc.tcp://192.168.0.10:4840'

client = Client(Endpoint)
input_values = ['S_init_est']

client.connect()


node = client.get_node('ns=3;s="{}"'.format("S_fim_de_esteira"))
node2 = client.get_node('ns=3;s="{}"'.format("S_fim_de_esteira"))
node3 = client.get_node('ns=3;s="{}"'.format("S_fim_de_esteira"))


nos = []

nos.append(node)
nos.append(node2)
nos.append(node3)

value = client.get_values(nos)

print(value)

