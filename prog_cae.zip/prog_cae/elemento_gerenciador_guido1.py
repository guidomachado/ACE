from opcua import Client
from opcua import server
import pymysql
import threading
import time
import cv2
import mysql.connector


def convert_data(step:list):

    #print("Convertendo o vetor para um numero binario. ")

    fator_multiplicativo = 1
    resultado = 0

    for elemento in reversed(step):

        #print("fator multiplicativo = ", fator_multiplicativo)

        if elemento == True:

            resultado = resultado + (1 * fator_multiplicativo)

        fator_multiplicativo = fator_multiplicativo * 2


   # print ("resultado: ", resultado)

    return resultado



def get_endpoint(planta_selecionada):

    sql = f"SELECT `Endpoint` FROM `plants` WHERE `Plant_name`= '{planta_selecionada}'"

    print(sql)

    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    data = mycursor.fetchone()

    

    mydb.close()

    #print(data[0])

    return data[0]

def get_experiment():
    sql = f"SELECT `Experiment_name` FROM `experiment` WHERE `Experiment_selected_bd`=1"
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    planta_selecionada = mycursor.fetchone()

    mydb.close()

    #print(planta_selecionada[0])

    return planta_selecionada[0]


def get_planta_selecionada():
    sql = f"SELECT `Plant_name` FROM `plants` WHERE `Plant_selected_bd`=1"
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    planta_selecionada = mycursor.fetchone()

    mydb.close()

    #print(planta_selecionada[0])

    return planta_selecionada[0]

def get_banco():

    # Conexão com o banco de dados MySQL
    db = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )

    cursor = db.cursor()

    return cursor, db

def get_foto(image_name:str):

    camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    camera.set(cv2.CAP_PROP_BRIGHTNESS, 2000)

    if camera.isOpened():

        validacao, frame = camera.read()

        #time.sleep(0.1)
    
        cv2.imwrite(image_name, frame)

def get_three_last_lines():

    with open('steps.txt', 'r') as file:

        lines = file.readlines()

    last_three_lines = lines[:3]

    three_lines = []

    if len(last_three_lines) != 3:

        print('n preencheu ainda ')

        return None
    
    for line in last_three_lines:

        line = line.strip()
        list = line.split('/')[0]
        list = list.replace('[', '')
        list = list.replace(']', '')

        #print(list)

        list = list.split(',')
        #print(list)

        for i in range(len(list)):

            list[i] = list[i].strip()

            if list[i] == 'False':

                list[i] = False

            else:

                list[i] = True
        
        #print(type(list[0]))

        three_lines.append(list)

    #print(three_lines)

    return three_lines

def get_values_input(experiment:str) ->str:

    conn = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    cursor = conn.cursor()

    cursor.execute(f'SELECT NameIO FROM cae.io WHERE Plant_name="{experiment}";')

    filenames = cursor.fetchall()

    cursor.close()
    conn.close()

    return filenames


def update_inputs():

    flag_passo = False

    count = 0

    cont = 0

    init = 0

    count_state = 0
    

    #cursor, db = get_banco()

    #server_ip = "172.21.1.1"
    planta_selecionada = get_planta_selecionada()

    Endpoint = get_endpoint(planta_selecionada)
    
    print(Endpoint)
    #time.sleep(3)
    #server_ip = "172.21.1.1"
    #client = Client("opc.tcp://{}:4840".format(server_ip))

    client = Client(Endpoint)
    print(planta_selecionada)
    #experiment = get_experiment() ->>>> mudar para get planta ta retornando experimento
    #input_values = ['xCL_BG7', 'xCL_BG8'] #get_values_input(planta_selecionada)
    input_values = ['xCL_BG7']
    #input_values = ['xCL_BG8']
    print(input_values)

    #print(experiment)
    #time.sleep(10)3
    states_IOs = []
    previous_state = []
    three_previous_state = []

    count_step = 0

            
    client.connect()

    lista_IOs = []
    
    for opcua_name in input_values:

        node = client.get_node('ns=3;s="{}"'.format(opcua_name))
        value = node.get_value()

        lista_IOs.append(opcua_name)
        #print(lista_IOs)
        
        #client.connect()
#with open('steps.txt', 'a') as file:
    inicio = time.time()
    #step = []   
    while True:
        


        try:

            #threeLines = get_three_last_lines()

            step = []
            #timestamp_atual = time.time()
            timestamp = time.time()
            firt_equal = 1

            #print(input_values)

            for opcua_name in input_values:

                node = client.get_node('ns=3;s="{}"'.format(opcua_name))
                value = node.get_value()
                #print(value)
                #time.sleep(5)
                #timestamp_atual = time.time()
                # cursor.execute("UPDATE inputs SET status = %s WHERE opcua_name = %s", (value, opcua_name))
                
                # db.commit()
                step.append(value)
            
            #print(f'comparando : {step} com {previous_state}')
            if step != previous_state:

                #states_IOs.append(convert_data(step)) 
                #actualtime = time.time()
                states_IOs.append(step)
                #states_IOs.append(actualtime)
                #print(states_IOs)
                #exit(1)

                #print('alterou')
                #timestamp_posterior = time.time()

                    #timestamp = timestamp_posterior - timestamp_atual

                #cont=cont+1

                #if step[1] == True:

                    #file.write(f"\n\n")
                    #cont = 0
                
                


                init = 0
                
                # if len(three_previous_state) == 3 :

                #     three_previous_state.pop()

                #     three_previous_state.append(step)
                    
                
                #else:

                    #three_previous_state.append(step)

                #exp_name = f'experiment_images/measuring_step_{count_step}.jpg'
                #thPhoto = threading.Thread(target=get_foto, args=(exp_name, ))
                #thPhoto.start()

                #get_foto(f'experiment_images/mag_back_step_{count_step}.jpg')
                #count_step = count_step + 1
                    
                    


            else:

                #print('São iguais!')
                pass



            if init == 0:

                previous_state = step

                init = 1
            
            # print('ultimos tres clp: ', three_previous_state)
            # print('\n ---- \n')
            #print('ultimos 3 txt: ', threeLines)

            # if (three_previous_state == threeLines):


            #     if firt_equal == 1:

            #         print('primeira rodada')
            #         firt_equal = 0
            #         three_previous_state = []
            #         #time.sleep(10)

                
            #     else:

            #         print('tres ultimos iguais fechando sistema')
            #         time.sleep(500)

        except Exception as e:

            print(f"Erro na atualização dos outputs: {e}")
        fim = time.time()  
        #print (fim-inicio)
        if(fim-inicio) > 15:
            cont = 0
            print(lista_IOs)
            print(states_IOs)
            exit(1)


        # count = count + 1

        # if count == 40:

        #     break
        


def main():

    update_inputs()    

if __name__ == "__main__":
    


    main()