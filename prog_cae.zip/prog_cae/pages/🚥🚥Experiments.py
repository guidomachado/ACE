import streamlit as st
import pandas as pd
import mysql.connector
import av
from streamlit_webrtc import webrtc_streamer
from streamlit_autorefresh import st_autorefresh


st.title("List of Experiments")

def video_frame_callback(img):

    img = img.to_ndarray(format="bgr24")

    return av.VideoFrame.from_ndarray(img, format="bgr24")


def executar_consulta(sql):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    data = mycursor.fetchall()
    columns = [desc[0] for desc in mycursor.description]
    df = pd.DataFrame(data, columns=columns)
    mydb.close()
    return df

def mostra_tabela_experimento():
    #sql4 = "SELECT * FROM io_opcua"
    query_experiments = "SELECT Experiment_name FROM `experiment`"
    result_experiments = executar_consulta(query_experiments)
    option = st.selectbox('Select Experiment',result_experiments, index=None)

    st.write('You selected:', option)
    if(option is None):
        st.header("No experiments were selected")
    else:    
        sql4 = f"SELECT `Experiment_name`, `Teacher_name`, `Experiment_status`, `Plant_name` FROM `experiment` WHERE Experiment_name = '{option}'"
        mp2 = executar_consulta(sql4)
        if (len(mp2) == 0):
            st.header("No experiments registered")
        else:

            def bolinha(status_item):
                cor = 'green' if status_item == 'Active' else 'red'
                return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'

            # Adicionando uma coluna de bolinhas ao DataFrame
            mp2['Status'] = mp2['Experiment_status'].apply(bolinha)

            # Exibindo a tabela com as bolinhas usando st.write
            st.write(mp2.to_html(escape=False), unsafe_allow_html=True)
    return option

select = mostra_tabela_experimento()
if (select == "Teste_magfront"):
    #st.set_page_config(page_title='Experiment One', page_icon='images/REMOTE LAB.png', layout='wide',  initial_sidebar_state='expanded')

    def control_LED(io_name, estado_LED):

        st.write(io_name)

        if estado_LED:

            st.image("images/led_on.png", width=100)

        else:

            st.image("images/led_off.png", width=100)
#############################################################

    st.title(select)

    col1, col2, col3, = st.columns([4, 2, 4])

    with col1:

        webrtc_streamer(key="sample", video_frame_callback=video_frame_callback)
        #st.image("images/festo_1.jpg")

    with col2:
        pass

    with col3:

        st.image("images/planta.png")


    # --------------------------------------------------------------------------------
    # --------------------------------------------------------------------------------

    if st.button("Rate experiment?", type="secondary"):
        st.write("Why hello there")
    else:
        st.write("")

    st.header("STEP MONITORING")

    colA, colB, colC, colD, colE = st.columns(5)
    co2A, co2B, co2C, co2D, co2E = st.columns(5)
    co3A, co3B, co3C, co3D, co3E = st.columns(5)

    with colA:

        led1 = st.toggle("IN 1", value=True, key="led1")
        
        control_LED('STEP 1', led1)

    with colB:

        led2 = st.toggle("IN 2", value=True, key="led2")

        control_LED('STEP 2', led2)

    with colC:

        led3 = st.toggle("IN 3", value=True, key="led3")

        control_LED('STEP 3', led3)

    with colD:

        led4 = st.toggle("IN 4", value=True, key="led4")

        control_LED('STEP 4', led4)

    with colE:

        led5 = st.toggle("IN 5", value=True, key="led5")

        control_LED('STEP 5', led5)
    

    with co2A:

        #led1 = st.toggle("IN 1", value=True, key="led1")
        
        control_LED('STEP 6', led1)

    with co2B:

        #led2 = st.toggle("IN 2", value=True, key="led2")

        control_LED('STEP 7', led2)

    with co2C:

        #led3 = st.toggle("IN 3", value=True, key="led3")

        control_LED('STEP 8', False)

    with co2D:

        #led4 = st.toggle("IN 4", value=True, key="led4")

        control_LED('STEP 9', False)

    with co2E:

        #led5 = st.toggle("IN 5", value=True, key="led5")

        control_LED('STEP 10', False)
    
    with co3A:

        #led1 = st.toggle("IN 1", value=True, key="led1")
        
        control_LED('STEP 11', False)

    with co3B:

        #led2 = st.toggle("IN 2", value=True, key="led2")

        control_LED('STEP 12', False)

    with co3C:

        #led3 = st.toggle("IN 3", value=True, key="led3")

        control_LED('STEP 13', False)

    with co3D:

        #led4 = st.toggle("IN 4", value=True, key="led4")

        control_LED('STEP 14', False)

    with co3E:

        #led5 = st.toggle("IN 5", value=True, key="led5")

        control_LED('STEP 15', False)