import streamlit as st
import pandas as pd
import mysql.connector
from streamlit_autorefresh import st_autorefresh


#def executar_consulta(sql):
#    mydb = mysql.connector.connect(
#        host="localhost",
#        user="root",
#        password="colares9187",
#        database="teste"
#    )
#    mycursor = mydb.cursor()
#    mycursor.execute(sql)
#    data = mycursor.fetchall()
#    columns = [desc[0] for desc in mycursor.description]
#    df = pd.DataFrame(data, columns=columns)
#    mydb.close()
#    return df
#
#def mostra_tabela_io_opcua():
#    sql4 = "SELECT * FROM io_opcua"
#    mp2 = executar_consulta(sql4)
#    def bolinha(status_item):
#        cor = 'green' if status_item == 'Ativo' else 'red'
#        return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'
#
#    # Adicionando uma coluna de bolinhas ao DataFrame
#    mp2['Bolinha'] = mp2['status_item'].apply(bolinha)
#
#    # Exibindo a tabela com as bolinhas usando st.write
#    st.write(mp2.to_html(escape=False), unsafe_allow_html=True)
    
    

def executar_consulta(sql):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    data = mycursor.fetchall()
    columns = [desc[0] for desc in mycursor.description]
    df = pd.DataFrame(data, columns=columns)
    mydb.close()
    return df


def inserir_dados_msg(msg, code_msg):
    mydb2 = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb2.cursor()
    sql3 = "INSERT INTO mensagem (msg, code_msg) VALUES (%s, %s)"
    val1 = (msg, code_msg)
    mycursor.execute(sql3, val1)
    mydb2.commit()  # Você esqueceu de commitar a transação
    mydb2.close()

def deletar_dados_msg(code_msg):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    sql = "DELETE FROM mensagem WHERE code_msg = %s"
    val = (code_msg,)
    mycursor.execute(sql, val)
    mydb.commit()
    mydb.close() 

def atualizar_dados_msg(code_msg, nova_msg):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    sql = "UPDATE mensagem SET msg = %s WHERE code_msg = %s"
    val = (nova_msg, code_msg)
    mycursor.execute(sql, val)
    mydb.commit()
    mydb.close()


#def inserir_dados_planta(Planta_id, plant_name,endpoint, io_opcua_id, plata_status ):
def inserir_dados_planta(School_name,Plant_name,Endpoint,Protocol):
    mydb3 = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb3.cursor()
    #sql4 = "INSERT INTO planta (Planta_id, plant_name,endpoint, io_opcua_id, plata_status) VALUES (%s, %s,%s, %s, %s)"
    #val2 = (Planta_id, plant_name,endpoint, io_opcua_id, plata_status)
    sql4 = "INSERT INTO plants (School_name,Plant_name,Endpoint,Protocol) VALUES (%s,%s,%s,%s)"
    val2 = (School_name,Plant_name,Endpoint,Protocol)
    mycursor.execute(sql4, val2)
    mydb3.commit()  # Você esqueceu de commitar a transação
    mydb3.close()

def inserir_dados_io_planta(Plant_name,NameIO,IO_type,PositionStatusIO):
    mydb3 = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb3.cursor()
    #sql4 = "INSERT INTO planta (Planta_id, plant_name,endpoint, io_opcua_id, plata_status) VALUES (%s, %s,%s, %s, %s)"
    #val2 = (Planta_id, plant_name,endpoint, io_opcua_id, plata_status)
    sql4 = "INSERT INTO io (Plant_name,NameIO,IO_type,PositionStatusIO) VALUES (%s,%s,%s,%s)"
    val2 = (Plant_name,NameIO,IO_type,PositionStatusIO)
    mycursor.execute(sql4, val2)
    mydb3.commit()  # Você esqueceu de commitar a transação
    mydb3.close()

def inserir_dados_experiments(Experiment_name,Teacher_name,Plant_name,Experiment_time):
    mydb3 = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb3.cursor()
    #sql4 = "INSERT INTO planta (Planta_id, plant_name,endpoint, io_opcua_id, plata_status) VALUES (%s, %s,%s, %s, %s)"
    #val2 = (Planta_id, plant_name,endpoint, io_opcua_id, plata_status)
    sql4 = "INSERT INTO experiment (Experiment_name,Teacher_name,Plant_name,Experiment_time) VALUES (%s,%s,%s,%s)"
    val2 = (Experiment_name,Teacher_name,Plant_name,Experiment_time)
    mycursor.execute(sql4, val2)
    mydb3.commit()  # Você esqueceu de commitar a transação
    mydb3.close()

def cadastrar_msg():
    
        st.subheader("Adicionar Dados de mensagem")

        # Campos para inserir nome e idade
        msg = st.text_input("Mensagem")
        code_msg = st.number_input("Código da mensagem", min_value=0, max_value=150, step=1)

        # Botão para inserir os dados
        if st.button("Inserir Dados", key="inserir_msg"):
            if msg and code_msg:
                inserir_dados_msg(msg, code_msg)
                st.success("Dados inseridos com sucesso!")
            else:
                st.error("Por favor, preencha todos os campos.")

def deletar_dados():
    st.subheader("Deletar Dados")
    code_msg_delete = st.text_input("Código da Mensagem para Deletar:")
    if st.button("Deletar"):
        deletar_dados_msg(code_msg_delete)
        st.success("Dados deletados com sucesso!")

def atualiza_tabela():
    
    st.subheader("Atualizar Dados")
    code_msg_update = st.text_input("Código da Mensagem para Atualizar:")
    nova_msg = st.text_input("Nova Mensagem:")
    if st.button("Atualizar"):
        atualizar_dados_msg(code_msg_update, nova_msg)
        st.success("Dados atualizados com sucesso!")

def cadastrar_planta():
    
        st.title("Create Remote Lab")

        # Campos para inserir nome e idade
        School_name = st.text_input("What is the name of the educational institution?")
        Plant_name = st.text_input("What is the name of the Remote Laboratory?")
        Endpoint = st.text_input("What is the access point?")
        Protocol = st.text_input("What is the protocol used?")
        #io_opcua_id  = st.number_input("IO OPCUA ID", min_value=0, max_value=150, step=1)
        #planta_status = st.text_input("Status (Ativo/ Inativo)")
        #planta_time_process = st.text_input("Tempo de processo da Planta")

        # Botão para inserir os dados
        if st.button("Insert", key="inserir_planta"):
            #if Planta_id and plant_name and endpoint and io_opcua_id and plata_status:
            if Plant_name and Endpoint:
                #inserir_dados_planta(Planta_id, plant_name,endpoint, io_opcua_id, plata_status)
                inserir_dados_planta(School_name,Plant_name,Endpoint,Protocol)
                st.success("Dados inseridos com sucesso!")
            else:
                st.error("Por favor, preencha todos os campos.")  

def cadastrar_io_planta():
    
        st.title("Add Inputs and Outputs of Experiment")

        # Campos para inserir nome e idade
        #Planta_id = st.text_input("ID planta")
        Plant_name = st.text_input("What is the name of lab?")
        NameIO = st.text_input("What is the name of I/O - Input/Output?")
        #var_action_r_w = st.text_input("W-Write or R-Read")
        #var_tipo  = st.number_input("E - Entrada ou S - Saída", min_value=0, max_value=150, step=1)
        IO_type  = st.text_input("What is the type: I/O - Input or Output?")
        
        PositionStatusIO = st.text_input("Start or End")

        # Botão para inserir os dados
        if st.button("Insert", key="inserir_E/S"):
            #if Planta_id and plant_name and endpoint and io_opcua_id and plata_status:
            if Plant_name and NameIO and IO_type:
                #inserir_dados_planta(Planta_id, plant_name,endpoint, io_opcua_id, plata_status)
                inserir_dados_io_planta(Plant_name,NameIO,IO_type,PositionStatusIO)
                st.success("Dados inseridos com sucesso!")
            else:
                st.error("Por favor, preencha todos os campos.")  

def cadastrar_experiments_planta():
    
        st.title("Create Experiments")

        # Campos para inserir nome e idade
        #Planta_id = st.text_input("ID planta")
        Experiment_name = st.text_input("What is the name of the experiment?")
        Teacher_name = st.text_input("What is the name of the professor responsible for the experiment?")
        #var_tipo  = st.number_input("E - Entrada ou S - Saída", min_value=0, max_value=150, step=1)
        Plant_name = st.text_input("What is the name of the Lab?")
        Experiment_time =st.text_input("What is the process time??")


        # Botão para inserir os dados
        if st.button("Insert", key="inserir_experiments"):
            #if Planta_id and plant_name and endpoint and io_opcua_id and plata_status:
            if Experiment_name and Teacher_name and Plant_name:
                #inserir_dados_planta(Planta_id, plant_name,endpoint, io_opcua_id, plata_status)
                inserir_dados_experiments(Experiment_name,Teacher_name,Plant_name,Experiment_time)
                st.success("Dados inseridos com sucesso!")
            else:
                st.error("Por favor, preencha todos os campos.")  


def atualiza_pagina():
    
    count = st_autorefresh(interval=100, limit=100, key="fizzbuzzcounter")

    # The function returns a counter for number of refreshes. This allows the
    # ability to make special requests at different intervals based on the count
    if count == 0:
        st.write("Count is zero")
    elif count % 3 == 0 and count % 5 == 0:
        st.write("FizzBuzz")
    elif count % 3 == 0:
        st.write("Fizz")
    elif count % 5 == 0:
        st.write("Buzz")
    else:
        st.write(f"Count: {count}")

def quarta_pagina():
    with st.expander("Create Lab"):
        #st.write("Aqui estão os detalhes adicionais que podem ser expandidos.")
        cadastrar_planta()

def quarta_pagina_io_planta():
    with st.expander("Create lab inputs and outputs"):
        #st.write("Aqui estão os detalhes adicionais que podem ser expandidos.")
        cadastrar_io_planta()

def quarta_pagina_experiments_planta():
    with st.expander("Create Experiments"):
        #st.write("Aqui estão os detalhes adicionais que podem ser expandidos.")
        cadastrar_experiments_planta()

def quinta_pagina():

    with st.expander("Atualizar mensagem"):
        #st.write("Aqui estão os detalhes adicionais que podem ser expandidos.")
        atualiza_tabela()
    with st.expander("Deletar mensagem"):
        #st.write("Aqui estão os detalhes adicionais que podem ser expandidos.")
        deletar_dados()
    with st.expander("Adicionar mensagem"):   
        cadastrar_msg()
        
        
def main():
    st.title("Register Lab")
    quarta_pagina()
    st.title("Registration of Inputs and Outputs")
    quarta_pagina_io_planta()
    st.title("Registration of Experiments")
    quarta_pagina_experiments_planta()

    # st.title("  Atualizar dados")
    # quinta_pagina()


if __name__ == "__main__":
    main()
    #atualiza_pagina()    
    