
import streamlit as st
import pandas as pd
import mysql.connector
from streamlit_autorefresh import st_autorefresh
st.title("List of Labs")

def executar_consulta(sql):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    data = mycursor.fetchall()
    columns = [desc[0] for desc in mycursor.description]
    df = pd.DataFrame(data, columns=columns)
    mydb.close()
    return df

def mostra_tabela_io_opcua():
    #sql4 = "SELECT * FROM io_opcua"
    query_plantas = "SELECT Plant_name FROM `plants`"
    result_plantas = executar_consulta(query_plantas)
    option = st.selectbox('selecione a planta desejada',result_plantas, index=None)

    st.write('You selected:', option)
    if(option is None):
        st.header("No experiments were selected")
    else:    
        sql4 = f"SELECT `Plant_name`, `NameIO`, `StatusIO`, `IO_type` FROM `io` WHERE plant_name = '{option}'"
        mp2 = executar_consulta(sql4)
        if (len(mp2) == 0):
            st.header("Nenhuma entrada ou saída foi cadastrada nesta planta")
        else:

            def bolinha(status_item):
                cor = 'green' if status_item == 'True' else 'red'
                return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'

            # Adicionando uma coluna de bolinhas ao DataFrame
            mp2['Status'] = mp2['StatusIO'].apply(bolinha)

            # Exibindo a tabela com as bolinhas usando st.write
            st.write(mp2.to_html(escape=False), unsafe_allow_html=True)


mostra_tabela_io_opcua()