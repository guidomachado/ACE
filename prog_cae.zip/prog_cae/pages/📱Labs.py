import streamlit as st
import pandas as pd
import mysql.connector
from streamlit_autorefresh import st_autorefresh
import time

planta_ligada = False

html_template1 = f'''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        .container {{
            display: flex;
            align-items: center;
        }}
        .bolinha {{
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: {'green' if planta_ligada else 'red'};
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5); /* Sombra */
            border: 2px solid #ccc; /* Borda cinza */
            margin-right: 10px;
        }}
        .comentario {{
            font-size: 16px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div id="bolinha" class="bolinha"></div>
        <div class="comentario" id="comentario">{'Planta ligada' if planta_ligada else 'Planta desligada'}</div>
    </div>

</body>
</html>
'''

print(html_template1)

def executar_consulta(sql):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    data = mycursor.fetchall()
    columns = [desc[0] for desc in mycursor.description]
    df = pd.DataFrame(data, columns=columns)
    mydb.close()
    return df



def mostra_tabelaCPLAB():
    
    sql8 = "SELECT plant_name , endpoint, planta_status, planta_time_process FROM planta WHERE plant_name = 'teste_guido' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
    
def mostra_tabelaA():
    
    sql8 = "SELECT plant_name , endpoint, planta_status, planta_time_process FROM planta WHERE plant_name = 'Planta A' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)

def mostra_tabelaB():
    
    sql8 = "SELECT plant_name , endpoint, planta_status, planta_time_process FROM planta WHERE plant_name = 'Planta B' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)

def mostra_tabelaC():
    
    sql8 = "SELECT plant_name , endpoint, planta_status, planta_time_process FROM planta WHERE plant_name = 'Planta C' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
    
def mostra_tabelaD():
    
    sql8 = "SELECT plant_name , endpoint, planta_status, planta_time_process FROM planta WHERE plant_name = 'Planta D' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
    
def mostra_tabelaE():
    
    sql8 = "SELECT plant_name , endpoint, planta_status, planta_time_process FROM planta WHERE plant_name = 'Planta E' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)
    
def mostra_tabelaABC():
    
    sql8 = "SELECT plant_name , endpoint, planta_status, planta_time_process FROM planta WHERE plant_name = 'Planta ABC' "
    mp5 = executar_consulta(sql8)
    mp5.set_index(mp5.columns[0], inplace=True)
    st.write(mp5)

    
def atualiza_pagina():
    
    count = st_autorefresh(interval=100, limit=100, key="fizzbuzzcounter")

    # The function returns a counter for number of refreshes. This allows the
    # ability to make special requests at different intervals based on the count
    if count == 0:
        st.write("")
    elif count % 3 == 0 and count % 5 == 0:
        st.write("")
    elif count % 3 == 0:
        st.write("")
    elif count % 5 == 0:
        st.write("")
    else:
        st.write(f"Count: {count}")
           

def listar_plantas():
 
    mydb7 = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="cae"
    )
    
    # Cursor para executar consultas SQL
    mycursor7 = mydb7.cursor()

    # Consulta para selecionar as plantas cadastradas
    sql7 = "SELECT `plant_name`, `endpoint`, `planta_status` FROM `planta`"

    # Executando a consulta
    mycursor7.execute(sql7)

    # Obtendo os resultados da consulta
    plantas = [plant[0] for plant in mycursor7.fetchall()]

    # Fechando a conexão com o banco de dados
    mydb7.close()
    
    # Criando o seletor de plantas no sidebar
    planta_selecionada = st.sidebar.selectbox("Selecione a planta", plantas)
    
    # if planta_selecionada == "Magfront":
    #     mostra_tabelaCPLAB()
        
    # if planta_selecionada == "MagBack":
    #     mostra_tabelaA()
    
    # if planta_selecionada == "Measuring":
    #     mostra_tabelaB()
        
    # if planta_selecionada == "Drill":
    #     mostra_tabelaC()
    
    # if planta_selecionada == "Planta D":
    #     mostra_tabelaD()
    
    # if planta_selecionada == "Planta E":
    #     mostra_tabelaE()
        
    # if planta_selecionada == "Planta ABC":
    #     mostra_tabelaABC()

    return planta_selecionada


#def status(status_item):
#    cor = 'green' if status_item == 'Ativo' else 'red'
#    return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'
#
## Adicionando uma coluna de statuss ao DataFrame
#mp2['status'] = mp2['status_item'].apply(status)
#
## Exibindo a tabela com as statuss usando st.write
#st.write(mp2.to_html(escape=False), unsafe_allow_html=True)

def tabela_io_cplab():
    sql4 = "SELECT io_opcua_id, item_opcua, status_item, time_on_out FROM io_opcua WHERE io_opcua_id = 1"
    mp2 = executar_consulta(sql4)
    mp2.set_index(mp2.columns[0], inplace=True)
    st.write(mp2)


    
def tabela_io_plantA():
    sql4 = "SELECT io_opcua_id, item_opcua, status_item, time_on_out FROM io_opcua WHERE io_opcua_id = 2"
    mp2 = executar_consulta(sql4)
    mp2.set_index(mp2.columns[0], inplace=True)
    st.write(mp2)
    def status(status_item):
        cor = 'green' if status_item == 'Ativo' else 'red'
        return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'

    # Adicionando uma coluna de statuss ao DataFrame
    mp2['status'] = mp2['status_item'].apply(status)

    # Exibindo a tabela com as statuss usando st.write
    st.write(mp2.to_html(escape=False), unsafe_allow_html=True)
    
def tabela_io_plantB():
    sql4 = "SELECT io_opcua_id, item_opcua, status_item, time_on_out FROM io_opcua WHERE io_opcua_id = 3"
    mp2 = executar_consulta(sql4)
    mp2.set_index(mp2.columns[0], inplace=True)
    st.write(mp2)
    def status(status_item):
        cor = 'green' if status_item == 'Ativo' else 'red'
        return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'

    # Adicionando uma coluna de statuss ao DataFrame
    mp2['status'] = mp2['status_item'].apply(status)

    # Exibindo a tabela com as statuss usando st.write
    st.write(mp2.to_html(escape=False), unsafe_allow_html=True)
    
    

def mostrar_todas_plantas():

    with st.expander("Magfront"):
        #st.write("Aqui estão os detalhes adicionais que podem ser expandidos.")
        mostra_tabelaCPLAB()
        tabela_io_cplab()
        
    with st.expander("MagBack"):
        #st.write("Aqui estão os detalhes adicionais que podem ser expandidos.")
        mostra_tabelaA()
        tabela_io_plantB()
    with st.expander("Measuring"): 
        mostra_tabelaB() 
        tabela_io_plantB() 
        



#def mostra_tabela_io_opcua():
#    sql4 = "SELECT * FROM io_opcua"
#    mp2 = executar_consulta(sql4)
#    def bolinha(status_item):
#        cor = 'green' if status_item == 'Ativo' else 'red'
#        return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'
#
#    # Adicionando uma coluna de bolinhas ao DataFrame
#    mp2['Bolinha'] = mp2['status_item'].apply(bolinha)
#
#    # Exibindo a tabela com as bolinhas usando st.write
#    st.write(mp2.to_html(escape=False), unsafe_allow_html=True)

def mostrar_plantas_geral_sembolinha():
   
    sql = "SELECT `plant_name`, `endpoint`, `planta_status`, `planta_time_process` FROM `planta`"
    df = executar_consulta(sql)
    df.set_index(df.columns[0], inplace=True)
    st.write(df)


def mostrar_plantas_geral():
    sql = "SELECT `School_name`, `Plant_name`, `Endpoint`, `Situation` FROM `plants`"
    df = executar_consulta(sql)
    # df.set_index(df.columns[0], inplace=True)
    # st.write(df)

    def bolinha_falha(planta_status):
        # cor = 'green' if planta_status == 'Ativo' else 'red'
        # cor = 'yellow' if planta_status == 'alarme' else 'red'
        if planta_status == 'Free':
            cor = 'green' 
        elif planta_status == 'Busy':
            cor = 'yellow'
        else:
            cor = 'red'
        return f'<div style="width: 20px; height: 20px; border-radius: 50%; background-color: {cor};"></div>'

    # Adicionando uma coluna de bolinhas ao DataFrame
    df['Status'] = df['Situation'].apply(bolinha_falha)

    # Exibindo a tabela com as bolinhas usando st.write
    st.write(df.to_html(escape=False), unsafe_allow_html=True)


def main():
    st.title("Labs")
    #st.sidebar.write("---")
    #plantas = listar_plantas()

    if 'count' not in st.session_state:
        st.session_state.count = 0
        
        placeholder = st.empty()
        while(1):
            placeholder.empty()
            st.session_state.count += 1
            
            #st.write('Count = ', st.session_state.count)
            with placeholder.container():
                mostrar_plantas_geral()
                time.sleep(1)
            

    #mostrar_todas_plantas()     
    


if __name__ == "__main__":
    main()
    #atualiza_pagina()    