from opcua import Client
import mysql.connector
import pandas as pd
import ua 
import time 

status_anterior = {}

def conectar_banco(host, user, password, database):
    """Conecta ao banco de dados MySQL."""
    conexao = mysql.connector.connect(
        host = host,
        user = user, 
        password = password,
        database = database
    )
    print("Conexão estabelecida com Sucesso!")
    return conexao 

# def obter_itens_banco(conexao, planta_selecionada):
#     """Obtém os identificadores dos nós (itens) no banco de dados."""
#     cursor = conexao.cursor()
#     query = f'SELECT item_opcua FROM io_opcua WHERE plant_name = {planta_selecionada}'
#     cursor.execute(query)
#     itens = [item[0] for item in cursor.fetchall()]
#     cursor.close()
#     return itens

def obter_itens_do_banco(planta_selecionada):
    """Obtém os identificadores dos nós (itens) no banco de dados."""

    query = f"SELECT item_opcua FROM io_opcua WHERE plant_name = '{planta_selecionada}'"
    itens = executar_consulta(query)

    return itens

def obter_item_de_start(planta_selecionada):
    """Obtém os identificadores dos nós (itens) no banco de dados."""
    #SELECT `status_item` FROM `io_opcua` WHERE `status_posicao`='INICIO' AND `status_item`='TRUE'
    sql = f"SELECT `status_item` FROM io_opcua WHERE `status_posicao`='INICIO' AND `status_item`='TRUE' AND plant_name = '{planta_selecionada}'"
    #state_start_item = executar_consulta(query)
##########################
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    state_start_item = mycursor.fetchone()

    mydb.close()


    return state_start_item

def obter_item_de_stop(planta_selecionada):
    """Obtém os identificadores dos nós (itens) no banco de dados."""
    #SELECT `status_item` FROM `io_opcua` WHERE `status_posicao`='INICIO' AND `status_item`='TRUE'
    sql = f"SELECT `status_item` FROM io_opcua WHERE `status_posicao`='FIM' AND `status_item`='TRUE' AND plant_name = '{planta_selecionada}'"
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    state_stop_item = mycursor.fetchone()

    mydb.close()
    return state_stop_item

def coletar_status_opcua(client:Client, item):

    """Coleta o status atual do item do servidor OPC UA."""
    
    node = client.get_node('ns=3;s="{}"'.format(item))
    
    status_atual = node.get_value()
    
    return status_atual

def enviar_status_banco(item, status, planta_selecionada):
    """Envia o status atualizado para o banco de dados."""
    #UPDATE `io_opcua` SET `status_item`='False' WHERE `item_opcua`= 'S_init_est'
    sql = f"UPDATE `io_opcua` SET `status_item` = '{status}' WHERE `item_opcua` = '{item}' AND `plant_name` = '{planta_selecionada}'"
    print(sql)
    # mydb = mysql.connector.connect(
    #     host="localhost",
    #     user="root",
    #     password="",
    #     database="teste"
    # )
    # mycursor = mydb.cursor()
    # mycursor.execute(comando_sql)
    # data = mycursor.fetchone()

    # mydb.close()

    # print(data[0])

    # return data[0]
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb.cursor()
    
    mycursor.execute(sql)
    mydb.commit()
    #data = mycursor.fetchone()
    data = mycursor.fetchall()

    mydb.close()
    # print("////////")
    # print(data)
    # print("////////")
    return data

def executar_consulta(sql):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )


    mycursor = mydb.cursor()
    mycursor.execute(sql)

    data = mycursor.fetchall()

    ''' Caso queira transformar em tabela para exibir no streamlit usa da forma abaixo'''

    # columns = [desc[0] for desc in mycursor.description]
    # df = pd.DataFrame(data, columns=columns)
    
    ''' Retornar como uma lista para utilizar no código '''

    nos = []

    for no in data:
        
        nos.append(no[0])

    mydb.close()

    return nos


''' 
def get_endpoint(planta_selecionada):
 
    sql = f"SELECT `endpoint` FROM `planta` WHERE `plant_name`= '{planta_selecionada}'"
    df = executar_consulta(sql)
    resp = df.set_index(df.columns[0], inplace=True)
    print(df)
    # Cursor para executar consultas SQL    
    return df

'''


def get_endpoint(planta_selecionada):
    sql = f"SELECT `endpoint` FROM `planta` WHERE `plant_name`= '{planta_selecionada}'"
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    data = mycursor.fetchone()

    mydb.close()

    print(data[0])

    return data[0]

def get_planta_selecionada():
    sql = f"SELECT `plant_name` FROM `planta` WHERE `planta_selecionada_bd`=1"
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="teste"
    )
    mycursor = mydb.cursor()
    mycursor.execute(sql)
    planta_selecionada = mycursor.fetchone()

    mydb.close()

    print(planta_selecionada[0])

    return planta_selecionada[0]

# def get_endpoint_only(planta_selecionada):
 
#     sql = f"SELECT `endpoint` FROM `planta` WHERE `plant_name`= '{planta_selecionada}'"
    
#     endpoint = get_endpoint(sql)

#     return endpoint

def main():


    time_contagem = False
    global status_anterior  # Define a variável como global para poder ser modificada dentro da função
    # Informações de conexão
    planta_selecionada = get_planta_selecionada()
    host = 'localhost'
    user = 'root'
    password = ''
    database = 'teste'
    #get_endpoint(planta_selecionada)
    # URL do servidor OPC UA
    
    #url_opcua = "opc.tcp://172.21.1.1:4840"
    url_opcua = get_endpoint(planta_selecionada)

    # Conecta ao banco de dados
    conexao = conectar_banco(host, user, password, database)

    # Conecta ao servidor OPC UA

    try:

        client = Client(url_opcua)
        client.connect()

    except ValueError as e:

        print('O USUARIO BOTOU UM IP ERRADO')



    print("Cliente OPC UA conectado!")

    while True:
        # Obtém os itens do banco de dados


        itens = obter_itens_do_banco(planta_selecionada)
        print(itens)


        # Para cada item, coleta o status atual do servidor OPC UA e envia para o banco de dados apenas se houver mudança
        for item in itens:

            try:

                status_atual = coletar_status_opcua(client, item)

                if status_atual is not None:  # Verifica se status_atual é None
                    # status_ant = status_anterior.get(item)
                    # if status_ant != status_atual:
                    #enviar_status_banco(item,status_atual)
                    #     status_anterior[item] = status_atual
                    print(item)
                    print(status_atual)
                    enviar_status_banco(item,status_atual, planta_selecionada)
                
                # # Espera um tempo antes de verificar novamente
                time.sleep(2)
                state_start_item = obter_item_de_start(planta_selecionada)
                print("aaaaaa")
                print(state_start_item)
                time.sleep(1)
                print("bbbbbb")
                if state_start_item is not None:
                    if(state_start_item[0] == 'True') and (time_contagem == False):
                        inicio = time.time()
                        time_contagem = True
                        print("tttttttttttt")
                state_stop_item = obter_item_de_stop(planta_selecionada)
                if state_stop_item is not None:    
                    if (state_stop_item[0] == 'True')and (time_contagem == True):
                        fim = time.time()
                        float(inicio)
                        print(fim - inicio)
                        print("nnnnnnnnnnnnnn")
                        time.sleep(5)
                        time_contagem = False   
            except ValueError as e:

                print('ao tentar pegar o no aconteceu o seguinte erro: ', e)



if __name__ == "__main__":

    main()
