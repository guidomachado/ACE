def convert_data(step:list):

    print("Convertendo o vetor para um numero binario. ")

    fator_multiplicativo = 1
    resultado = 0

    for elemento in reversed(step):

        print("fator multiplicativo = ", fator_multiplicativo)

        if elemento == True:

            resultado = resultado + (1 * fator_multiplicativo)

        fator_multiplicativo = fator_multiplicativo * 2


    print ("resultado: ", resultado)

    return resultado


print([[123], [123]])
